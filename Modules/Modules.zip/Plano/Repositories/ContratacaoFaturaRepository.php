<?php

namespace Modules\Plano\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ContratacaoFaturaRepository
 * @package namespace Modules\Plano\Repositories;
 */
interface ContratacaoFaturaRepository extends RepositoryInterface
{
    //
}
