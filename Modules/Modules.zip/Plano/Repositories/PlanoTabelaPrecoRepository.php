<?php

namespace Modules\Plano\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PlanoTabelaPrecoRepository
 * @package namespace Modules\Plano\Repositories;
 */
interface PlanoTabelaPrecoRepository extends RepositoryInterface
{
    //
}
