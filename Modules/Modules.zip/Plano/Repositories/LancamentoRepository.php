<?php

namespace Modules\Plano\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface LancamentoRepository
 * @package namespace Modules\Plano\Repositories;
 */
interface LancamentoRepository extends RepositoryInterface
{
    //
}
