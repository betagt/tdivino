<?php

return [
    'name' => 'GeoPosition'
];
