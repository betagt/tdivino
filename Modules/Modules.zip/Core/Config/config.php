<?php

return [
    'name' => 'Core'
];
