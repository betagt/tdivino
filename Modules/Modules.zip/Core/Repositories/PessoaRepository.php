<?php

namespace Modules\Core\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PessoaRepository
 * @package namespace Portal\Repositories;
 */
interface PessoaRepository extends RepositoryInterface
{
    //
}
