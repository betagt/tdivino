<?php

namespace Modules\Core\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface NewsletterRepository
 * @package namespace Portal\Repositories;
 */
interface NewsletterRepository extends RepositoryInterface
{
    //
}
