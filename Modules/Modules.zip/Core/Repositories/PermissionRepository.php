<?php

namespace Modules\Core\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PermissionRepository
 * @package namespace Modules\Core\Repositories;
 */
interface PermissionRepository extends RepositoryInterface
{
    //
}
