<?php

return [
    'name' => 'Localidade'
];
