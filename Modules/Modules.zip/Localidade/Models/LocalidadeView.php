<?php

namespace Modules\Localidade\Models;

use Illuminate\Database\Eloquent\Model;

class LocalidadeView extends Model
{
    protected $table = '_localidades';
}
