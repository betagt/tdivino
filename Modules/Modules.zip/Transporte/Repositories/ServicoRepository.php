<?php

namespace  Modules\Transporte\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ServicoRepository
 * @package namespace Portal\Repositories;
 */
interface ServicoRepository extends RepositoryInterface
{
    //
}
