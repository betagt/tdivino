<?php

namespace  Modules\Transporte\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ContaRepository
 * @package namespace Portal\Repositories;
 */
interface ContaRepository extends RepositoryInterface
{
    //
}
