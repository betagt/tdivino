<?php

namespace Modules\Transporte\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface GeoPosicaoRepository
 * @package namespace Portal\Repositories;
 */
interface GeoPosicaoRepository extends RepositoryInterface
{
    //
}
