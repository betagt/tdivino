<?php

namespace Modules\Transporte\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface MarcaCarroRepository
 * @package namespace Portal\Repositories;
 */
interface MarcaCarroRepository extends RepositoryInterface
{
    //
}
