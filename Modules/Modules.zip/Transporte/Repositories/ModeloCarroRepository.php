<?php

namespace Modules\Transporte\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ModeloCarroRepository
 * @package namespace Portal\Repositories;
 */
interface ModeloCarroRepository extends RepositoryInterface
{
    //
}
